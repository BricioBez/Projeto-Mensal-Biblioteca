package Modelos;

   public enum TipoUsuario {
    ALUNO,
    PROFESSOR,
    FUNCIONARIO
}
